package com.nxw.config;

import com.nxw.dataSource.DataSourceContextHolder;
import com.nxw.dataSource.MyRoutingDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Configuration
public class DataSourceConfiguration {
    @Value("${spring.datasource.type}")
    private Class<? extends DataSource> dataSourceType;

    @Value("${datasource.readSize}")
    private String readDataSourceSize;

    @Bean(name="writeDataSource")
    //@Primary
    @ConfigurationProperties(prefix = "spring.write.datasource")
    public DataSource writeDataSource() {
        return DataSourceBuilder.create().type(dataSourceType).build();
    }

    @Bean(name="readDataSourceOne")
    @ConfigurationProperties(prefix = "spring.read.one")
    public DataSource readDataSourceOne() {
        return DataSourceBuilder.create().type(dataSourceType).build();
    }

    @Bean(name="readDataSourceTwo")
    @ConfigurationProperties(prefix = "spring.read.two")
    public DataSource readDataSourceTwo() {
        return DataSourceBuilder.create().type(dataSourceType).build();
    }

    public List<DataSource> readDataSourceList() {
        List<DataSource> dataSourceList = new ArrayList<DataSource>();
        dataSourceList.add(readDataSourceOne());
        dataSourceList.add(readDataSourceTwo());
        return dataSourceList;
    }

    @Bean(name="proxyDataSource")
    public AbstractRoutingDataSource roundRobinDataSourceProxy() {
        int size = Integer.parseInt(readDataSourceSize);
        MyRoutingDataSource proxy = new MyRoutingDataSource(size);
        Map<Object, Object> targetDataSources =  new HashMap<>();
        DataSource writeDataSource = writeDataSource();
        targetDataSources.put(DataSourceContextHolder.DATA_SOURCE_WRITE, writeDataSource);
        List<DataSource> readDataSourceList = readDataSourceList();
        for (int i = 0; i < size; i++) {
            targetDataSources.put(i, readDataSourceList.get(i));
        }
        proxy.setDefaultTargetDataSource(writeDataSource);
        proxy.setTargetDataSources(targetDataSources);

        return proxy;
    }
}
