package com.nxw.dao;

import com.nxw.dto.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface UserDao {
    int insert(User user);

    int update(User user);

    User findByName(@Param("userName") String userName);
}
