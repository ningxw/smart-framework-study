package com.nxw.resource;

import com.nxw.dto.User;
import com.nxw.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/user")
public class UserResource {
    @Autowired
    private UserService userService;

    @RequestMapping(value = "/addUser", method = RequestMethod.POST)
    public boolean addUser(User user) {
        System.out.println("adding user");
        return userService.addUser(user);
    }

    @RequestMapping("/greeting")
    public String home() {
        return "Hello World!";
    }

    @RequestMapping(value = "/userName", method = RequestMethod.GET)
    public User findByUserName(@RequestParam(value = "userName") String userName) {
        return userService.findByUserName(userName);
    }
}
