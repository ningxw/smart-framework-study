package com.nxw.dataSource;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

import java.util.concurrent.atomic.AtomicInteger;

public class MyRoutingDataSource extends AbstractRoutingDataSource {
    private int dataSourceSize;
    private AtomicInteger count = new AtomicInteger(0);

    public MyRoutingDataSource(int dataSourceSize) {
        this.dataSourceSize = dataSourceSize;
    }

    @Override
    protected Object determineCurrentLookupKey() {
        String type = DataSourceContextHolder.getType();
        if (type.equals(DataSourceContextHolder.DATA_SOURCE_WRITE)) {
            return type;
        }

        // 读 简单负载均衡
        int number = count.getAndAdd(1);
        int lookupKey = number % dataSourceSize;
        return new Integer(lookupKey);
    }
}
