package com.nxw.service.impl;

import com.nxw.annotation.Log;
import com.nxw.dao.UserDao;
import com.nxw.dto.User;
import com.nxw.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserDao userDao;

    @Transactional
    @Override
    public boolean addUser(User user) {
        userDao.insert(user);
        System.out.println(user.getId());
        throw new RuntimeException("test transactional");
        //return true;
    }

    @Log
    @Override
    public User findByUserName(String userName) {
        User user = userDao.findByName(userName);
        return user;
    }
}
