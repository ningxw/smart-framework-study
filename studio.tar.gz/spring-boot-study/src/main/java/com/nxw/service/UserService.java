package com.nxw.service;

import com.nxw.dto.User;

public interface UserService {

    /**
     *
     * @param user
     * @return
     */
    boolean addUser(User user);

    /**
     *
     * @param userName
     * @return
     */
    User findByUserName(String userName);
}
