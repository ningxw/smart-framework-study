package com.nxw.aop;

import com.nxw.dataSource.DataSourceContextHolder;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class DataSourceAop {
    @Pointcut("@annotation(com.nxw.annotation.Log)")
    public void logAspect() {

    }

    @Around("logAspect()")
    public Object log(ProceedingJoinPoint pjp) throws Throwable {
        System.out.println("before");
        Object obj = pjp.proceed();
        System.out.println("after");
        return obj;
    }

    @Before("execution(* com.nxw.dao..*.find*(..))")
    public void setReadDataSourceType() {
        DataSourceContextHolder.read();
        System.out.println("read=========");
    }

    @Before("execution(* com.nxw.dao..*.insert*(..))")
    public void setWriteDataSourceType() {
        DataSourceContextHolder.write();
        System.out.println("write=========");
    }
}
